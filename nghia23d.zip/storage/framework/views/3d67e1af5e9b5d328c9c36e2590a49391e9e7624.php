<!DOCTYPE html>
<html lang="vi">

<head>
    <?php echo $__env->make('blocks.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <?php echo $__env->make('elements.preload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="wrapper-page">
        <?php echo $__env->make('blocks.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Main Content Pages -->
        <div class="content-pages">
            <!-- Subpages -->
            <div class="sub-home-pages">
                <!-- Start Page home -->
                <section id="home" class="sub-page start-page">
                    <div class="sub-page-inner">
                        <div class="mask"></div>
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12">
                                <div class="title-block">
                                    <h2>Hello I'm Nghia23d</h2>
                                    <div class="type-wrap">
                                        <div class="typed-strings">
                                            <span>Web Developer</span>
                                            <span>Photographer</span>
                                            <span>Blogger</span>
                                        </div>
                                        <span class="typed"></span>
                                    </div>
                                    <div class="home-buttons">
                                        <a href="#contact" class="bt-submit"><i class="lnr lnr-envelope"></i> Contact
                                            Me</a>
                                        <a href="#contact" class="bt-submit"><i class="lnr lnr-briefcase"></i> Hire
                                            Me</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- /Start Page home -->

                <!-- About Me Subpage -->
                <section id="about-me" class="sub-page">
                    <div class="sub-page-inner">
                        <div class="section-title">
                            <div class="main-title">
                                <div class="title-main-page">
                                    <h4>About me</h4>
                                    <p>Lorem ipsum dolor sit amet</p>
                                </div>
                            </div>
                        </div>
                        <div class="section-content">
                            <!-- about me -->
                            <div class="row pb-30">
                                <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                    <h3>Mulan Rafiky</h3>
                                    <span class="about-location"><i class="lnr lnr-map-marker"></i> United States,
                                        America</span>
                                    <p class="about-content">
                                        Praesent ut tortor consectetur, semper sapien non, lacinia augue. Aenean arcu
                                        libero, facilisis et nisi non, tempus faucibus tortor. Mauris vel nulla aliquam,
                                        pellentesque enim ac, faucibus tortor. Nulla odio nibh, cursus sit amet urna id,
                                        dignissim euismod augue
                                    </p>
                                    <p class="about-content">
                                        Praesent ut tortor consectetur, semper sapien non, lacinia augue. Aenean arcu
                                        libero, facilisis et nisi non, tempus faucibus tortor. Mauris vel nulla aliquam,
                                        pellentesque enim ac, faucibus tortor. Nulla odio nibh, cursus sit amet urna id,
                                        dignissim euismod augue
                                    </p>
                                    <ul class="bout-list-summry row">
                                        <li class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                            <div class="icon-info">
                                                <i class="lnr lnr-briefcase"></i>
                                            </div>
                                            <div class="details-info">
                                                <h6>5 Years+ Job</h6>
                                                <p>Experience</p>
                                            </div>
                                        </li>
                                        <li class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                            <div class="icon-info">
                                                <i class="lnr lnr-layers"></i>
                                            </div>
                                            <div class="details-info">
                                                <h6>300+ Projects</h6>
                                                <p>Completed</p>
                                            </div>
                                        </li>
                                        <li class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                                            <div class="icon-info">
                                                <i class="lnr lnr-coffee-cup"></i>
                                            </div>
                                            <div class="details-info">
                                                <h6>150+ Meetings</h6>
                                                <p>Successful</p>
                                            </div>
                                        </li>
                                    </ul>
                                </div>

                                <div class="col-xs-6 col-sm-12 col-md-6 col-lg-6">
                                    <div class="box-img">
                                        <img src="images/about.png" class="img-fluid" alt="image">
                                    </div>
                                </div>
                            </div>
                            <!-- /about me -->

                            <!-- services -->
                            <div class="special-block-bg">
                                <div class="section-head">
                                    <h4>
                                        <span>What Actually I Do</span>
                                        My Services
                                    </h4>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <div class="services-list">
                                            <!-- Service Item 1 -->
                                            <div class="service-block">
                                                <div class="service-icon">
                                                    <i class="lnr lnr-code"></i>
                                                </div>
                                                <div class="service-text">
                                                    <h4>Web Development</h4>
                                                    <p>Pellentesque pellentesque, ipsum sit amet auctor accumsan, odio
                                                        tortor bibendum massa, sit amet ultricies ex lectus scelerisque
                                                        nibh. Ut non sodales odio.</p>
                                                </div>
                                            </div>
                                            <!-- /Service Item 1 -->

                                            <!-- Service Item 2 -->
                                            <div class="service-block">
                                                <div class="service-icon">
                                                    <i class="lnr lnr-laptop-phone"></i>
                                                </div>
                                                <div class="service-text">
                                                    <h4>Web Design</h4>
                                                    <p>Pellentesque pellentesque, ipsum sit amet auctor accumsan, odio
                                                        tortor bibendum massa, sit amet ultricies ex lectus scelerisque
                                                        nibh. Ut non sodales odio.</p>
                                                </div>
                                            </div>
                                            <!-- Service Item 2 -->
                                        </div>
                                    </div>

                                    <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">
                                        <div class="services-list">
                                            <!-- Service Item 3 -->
                                            <div class="service-block">
                                                <div class="service-icon">
                                                    <i class="lnr lnr-mic"></i>
                                                </div>
                                                <div class="service-text">
                                                    <h4>Voice Recorder</h4>
                                                    <p>Pellentesque pellentesque, ipsum sit amet auctor accumsan, odio
                                                        tortor bibendum massa, sit amet ultricies ex lectus scelerisque
                                                        nibh. Ut non sodales odio.</p>
                                                </div>
                                            </div>
                                            <!-- Service Item 3 -->

                                            <!-- Service Item 4 -->
                                            <div class="service-block">
                                                <div class="service-icon">
                                                    <i class="lnr lnr-camera"></i>
                                                </div>
                                                <div class="service-text">
                                                    <h4>Photography</h4>
                                                    <p>Pellentesque pellentesque, ipsum sit amet auctor accumsan, odio
                                                        tortor bibendum massa, sit amet ultricies ex lectus scelerisque
                                                        nibh. Ut non sodales odio.</p>
                                                </div>
                                            </div>
                                            <!-- Service Item 4 -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /services -->

                            <!-- Video section -->
                            <div class="video-section">
                                <div class="overlay pb-40 pt-40">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7">
                                                <div class="sub-title">
                                                    <h6>Why You Hire Me?</h6>
                                                    <h2>I Am The Best Front End Expert in the marketplace</h2>
                                                </div>
                                            </div>
                                            <div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">
                                                <div class="pulse-icon">
                                                    <div class="icon-wrap">
                                                        <a href="https//www.youtube.com/">
                                                            <i class="fa fa-play"></i>
                                                        </a>
                                                    </div>
                                                    <div class="elements">
                                                        <div class="circle circle-outer"></div>
                                                        <div class="circle circle-inner"></div>
                                                        <div class="pulse pulse-1"></div>
                                                        <div class="pulse pulse-2"></div>
                                                        <div class="pulse pulse-3"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /Video section -->

                            <!-- Fun Facts -->
                            <div class="row pb-30 pt-30">
                                <div class="section-head col-sm-12">
                                    <h4>
                                        <span>Fun</span>
                                        Facts
                                    </h4>
                                </div>
                                <!-- Item 1 -->
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                                    <div class="pb-30">
                                        <div class="counter-block">
                                            <i class="pe-7s-smile"></i>
                                            <h4>Happy Clients</h4>
                                            <span class="counter-block-value" data-count="1000">0</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- /Item 1-->

                                <!-- Item 2 -->
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                                    <div class="pb-30">
                                        <div class="counter-block">
                                            <i class="pe-7s-light"></i>
                                            <h4>Experiences Years</h4>
                                            <span class="counter-block-value" data-count="7">0</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- /Item 2 -->

                                <!-- Item 3-->
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                                    <div class="pb-30">
                                        <div class="counter-block">
                                            <i class="pe-7s-cup"></i>
                                            <h4>Awards Won</h4>
                                            <span class="counter-block-value" data-count="15">0</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- /Item 3 -->

                                <!-- Item 4-->
                                <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
                                    <div class="pb-30">
                                        <div class="counter-block">
                                            <i class="pe-7s-coffee"></i>
                                            <h4>Meetings</h4>
                                            <span class="counter-block-value" data-count="500">0</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- /Item 4-->
                            </div>
                            <!-- /Fun Facts -->

                            <!-- List Of Testimonials -->
                            <div class="special-block-bg">
                                <div class="section-head">
                                    <h4>
                                        <span>What My Freedom</span>
                                        Client Say
                                    </h4>
                                </div>
                                <div class="testimonials owl-carousel">
                                    <!-- Testimonial item 1 -->
                                    <div class="testimonial-item">
                                        <div class="testimonial-content">
                                            <div class="testimonial-review">
                                                <p>Wow what great experience, I love it! It's exactly what I've been
                                                    looking for. Anna's group was the best investment I ever made. I
                                                    don't know if I would have ever made it without her guidance and
                                                    support!</p>
                                            </div>
                                        </div>
                                        <div class="testimonial-footer">
                                            <div class="testimonial-avatar">
                                                <img src="images/testimonials/testimonial-avatar-1.jpeg"
                                                    alt="Gary Johnson" />
                                            </div>
                                            <div class="testimonial-owner-content">
                                                <p class="testimonial-owner">Johny Melion</p>
                                                <p class="testimonial-position">General Manager</p>
                                                <ul class="testimonial-rating">
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /Testimonial item 1 -->

                                    <!-- Testimonial item 2 -->
                                    <div class="testimonial-item">
                                        <div class="testimonial-content">
                                            <div class="testimonial-review">
                                                <p>I like this group more and more each day. It makes my life a lot
                                                    easier. It's really wonderful to be able to get support from like
                                                    minded entrepreneurs. And Anna is always available to advise us.
                                                    Thank you so much!</p>
                                            </div>
                                        </div>
                                        <div class="testimonial-footer">
                                            <div class="testimonial-avatar">
                                                <img src="images/testimonials/testimonial-avatar-2.jpeg"
                                                    alt="Daniel Pringle" />
                                            </div>
                                            <div class="testimonial-owner-content">
                                                <p class="testimonial-owner">Marita Swingy</p>
                                                <p class="testimonial-position">Project Manager</p>
                                                <ul class="testimonial-rating">
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star-half-alt"></i></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /Testimonial item 2 -->

                                    <!-- Testimonial item 3 -->
                                    <div class="testimonial-item">
                                        <div class="testimonial-content">
                                            <div class="testimonial-review">
                                                <p>I like this group more and more each day. It makes my life a lot
                                                    easier. It's really wonderful to be able to get support from like
                                                    minded entrepreneurs. And Anna is always available to advise us.
                                                    Thank you so much!</p>
                                            </div>
                                        </div>
                                        <div class="testimonial-footer">
                                            <div class="testimonial-avatar">
                                                <img src="images/testimonials/testimonial-avatar-3.jpeg"
                                                    alt="Billy Adams" />
                                            </div>
                                            <div class="testimonial-owner-content">
                                                <p class="testimonial-owner">Flyn Jumary</p>
                                                <p class="testimonial-position">Sales Manager</p>
                                                <ul class="testimonial-rating">
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                    <li><i class="fa fa-star"></i></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /Testimonial item 3 -->
                                </div>

                            </div>
                            <!-- /List Of Testimonials -->

                            <!-- Clients -->
                            <div class="row pt-50">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <div class="section-head">
                                        <h4>
                                            <span>My</span>
                                            Clients
                                        </h4>
                                    </div>
                                    <!-- List Of Clients -->
                                    <div class="clients owl-carousel">
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                        <div class="client-block">
                                            <a href="#" target="_blank" title="Client">
                                                <img src="images/clients/3.png" alt="Client">
                                            </a>
                                        </div>
                                    </div>
                                    <!-- /List Of Clients -->
                                </div>
                            </div>
                            <!-- /Clients Block -->
                        </div>
                    </div>
                </section>
                <!-- About Me Subpage -->

                <!-- Resume Subpage -->
                
                <!-- End of Resume Subpage -->

                <!-- Portfolio Subpage -->
                <section id="portfolio" class="sub-page">
                    <div class="sub-page-inner">
                        <div class="section-title">
                            <div class="main-title">
                                <div class="title-main-page">
                                    <h4>Portfolio</h4>
                                    <p>Samples of some of my work from the past year.</p>
                                </div>
                            </div>
                        </div>

                        <div class="section-content">
                            <div class="filter-tabs">
                                <button class="fil-cat" data-rel="all"><span>0</span> All</button>
                                <button class="fil-cat" data-rel="photography"><span>05</span> Websites</button>
                                <button class="fil-cat" data-rel="web-design"><span>07</span> Decorations</button>
                                <button class="fil-cat" data-rel="branding"><span>12</span> Business Logo</button>
                            </div>

                            <div class="portfolio-grid portfolio-trigger" id="portfolio-page">
                                <div class="label-portfolio"><span class="rotated-sub">project</span><span
                                        class="project-count">8</span></div>
                                <div class="row">
                                    <div
                                        class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-item branding photography all">
                                        <div class="portfolio-img">
                                            <img src="images/portfolio/portfolio-img-1.jpeg" class="img-responsive"
                                                alt="">
                                        </div>
                                        <div class="portfolio-data">
                                            <h4><a href="portfolio-single.html">Company Branding</a></h4>
                                            <p class="meta">Branding + Photography</p>
                                            <div class="portfolio-attr">
                                                <a href="portfolio-single.html"><i class="lnr lnr-link"></i></a>
                                                <a href="images/portfolio/portfolio-img-1.jpeg"
                                                    data-rel="lightcase:gal" title="Image Caption"><i
                                                        class="lnr lnr-move"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div
                                        class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-item web-design branding all">
                                        <div class="portfolio-img"><img src="images/portfolio/portfolio-img-2.jpeg"
                                                class="img-responsive" alt=""></div>
                                        <div class="portfolio-data">
                                            <h4><a href="portfolio-single.html">Home Decoration</a></h4>
                                            <p class="meta">Web design + Branding</p>
                                            <div class="portfolio-attr">
                                                <a href="portfolio-single.html"><i class="lnr lnr-link"></i></a>
                                                <a href="images/portfolio/portfolio-img-2.jpeg"
                                                    data-rel="lightcase:gal" title="Image Caption"><i
                                                        class="lnr lnr-move"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-item branding all">
                                        <div class="portfolio-img"><img src="images/portfolio/portfolio-img-3.jpeg"
                                                class="img-responsive" alt=""></div>
                                        <div class="portfolio-data">
                                            <h4><a href="portfolio-single.html">Photography</a></h4>
                                            <p class="meta">Branding</p>
                                            <div class="portfolio-attr">
                                                <a href="portfolio-single.html"><i class="lnr lnr-link"></i></a>
                                                <a href="images/portfolio/portfolio-img-3.jpeg"
                                                    data-rel="lightcase:gal" title="Image Caption"><i
                                                        class="lnr lnr-move"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div
                                        class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-item web-design branding all">
                                        <div class="portfolio-img"><img src="images/portfolio/portfolio-img-4.jpeg"
                                                class="img-responsive" alt=""></div>
                                        <div class="portfolio-data">
                                            <h4><a href="portfolio-single.html">Furniture branding</a></h4>
                                            <p class="meta">Web design + Branding</p>
                                            <div class="portfolio-attr">
                                                <a href="portfolio-single.html"><i class="lnr lnr-link"></i></a>
                                                <a href="images/portfolio/portfolio-img-4.jpeg"
                                                    data-rel="lightcase:gal" title="Image Caption"><i
                                                        class="lnr lnr-move"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-item branding all">
                                        <div class="portfolio-img"><img src="images/portfolio/portfolio-img-5.jpeg"
                                                class="img-responsive" alt=""></div>
                                        <div class="portfolio-data">
                                            <h4><a href="portfolio-single.html">Flowers power</a></h4>
                                            <p class="meta">Branding</p>
                                            <div class="portfolio-attr">
                                                <a href="portfolio-single.html"><i class="lnr lnr-link"></i></a>
                                                <a href="images/portfolio/portfolio-img-5.jpeg"
                                                    data-rel="lightcase:gal" title="Image Caption"><i
                                                        class="lnr lnr-move"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div
                                        class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-item web-design branding all">
                                        <div class="portfolio-img"><img src="images/portfolio/portfolio-img-6.jpeg"
                                                class="img-responsive" alt=""></div>
                                        <div class="portfolio-data">
                                            <h4><a href="portfolio-single.html">Furniture branding</a></h4>
                                            <p class="meta">Web design + Branding</p>
                                            <div class="portfolio-attr">
                                                <a href="portfolio-single.html"><i class="lnr lnr-link"></i></a>
                                                <a href="images/portfolio/portfolio-img-6.jpeg"
                                                    data-rel="lightcase:gal" title="Image Caption"><i
                                                        class="lnr lnr-move"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-item branding all">
                                        <div class="portfolio-img"><img src="images/portfolio/portfolio-img-7.jpeg"
                                                class="img-responsive" alt=""></div>
                                        <div class="portfolio-data">
                                            <h4><a href="portfolio-single.html">Flowers power</a></h4>
                                            <p class="meta">Branding</p>
                                            <div class="portfolio-attr">
                                                <a href="portfolio-single.html"><i class="lnr lnr-link"></i></a>
                                                <a href="images/portfolio/portfolio-img-7.jpeg"
                                                    data-rel="lightcase:gal" title="Image Caption"><i
                                                        class="lnr lnr-move"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div
                                        class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-item web-design branding all">
                                        <div class="portfolio-img"><img src="images/portfolio/portfolio-img-8.jpeg"
                                                class="img-responsive" alt=""></div>
                                        <div class="portfolio-data">
                                            <h4><a href="portfolio-single.html">Furniture branding</a></h4>
                                            <p class="meta">Web design + Branding</p>
                                            <div class="portfolio-attr">
                                                <a href="portfolio-single.html"><i class="lnr lnr-link"></i></a>
                                                <a href="images/portfolio/portfolio-img-8.jpeg"
                                                    data-rel="lightcase:gal" title="Image Caption"><i
                                                        class="lnr lnr-move"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- /Portfolio Subpage -->

                <!-- Blog Subpage -->
                <section id="blog" class="sub-page">
                    <div class="sub-page-inner">
                        <div class="section-title">
                            <div class="main-title">
                                <div class="title-main-page">
                                    <h4>Blog</h4>
                                    <p>We share our news and blog</p>
                                </div>
                            </div>
                        </div>

                        <div class="section-content">
                            <div class="row blog-grid-flex">
                                <div class="col-md-4 col-sm-6 blog-item-quote blog-item">
                                    <div class="blog-article">
                                        <div class="post-format"> <span class="post-format-icon"><i
                                                    class="fas fa-quote-right"></i></span> </div>
                                        <div class="comment-like"> <span><i class="fas fa-comment"
                                                    aria-hidden="true"></i> 30</span> <span><i class="fas fa-heart"
                                                    aria-hidden="true"></i> 15</span> </div>
                                        <div class="article-img">
                                            <a href="blog-single.html"><img src="images/blog/1.jpeg"
                                                    class="img-responsive" alt=""></a>
                                        </div>
                                        <div class="article-content">
                                            <div>
                                                <h4><a href="blog-single.html">Design is not just what it looks like
                                                        .Design is how it works .</a></h4>
                                                <div class="meta"> <span><i>Feb</i> 16,2016</span> <span><i>In</i> <a
                                                            href="#">Shopping</a></span> <span><i>Tags</i> <a
                                                            href="#">Trends</a></span> </div>
                                                <div class="article-link"> <a href="blog-single.html"><i
                                                            class="lnr lnr-arrow-right"></i></a> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-8 col-sm-6 blog-item">
                                    <div class="blog-article">
                                        <div class="post-format"> <span class="post-format-icon"><i
                                                    class="lnr lnr-picture"></i></span> </div>
                                        <div class="comment-like"> <span><i class="fas fa-comment"
                                                    aria-hidden="true"></i> 30</span> <span><i class="fas fa-heart"
                                                    aria-hidden="true"></i> 15</span> </div>
                                        <div class="article-img">
                                            <a href="blog-single.html"> <img src="images/blog/2.jpeg"
                                                    class="img-responsive" alt=""></a>
                                        </div>
                                        <div class="article-link"> <a href="blog-single.html"><i
                                                    class="lnr lnr-arrow-right"></i></a> </div>
                                        <div class="article-content">
                                            <h4><a href="blog-single.html">The new clear bolg </a></h4>
                                            <div class="meta"> <span><i>Feb</i> 16,2016</span> <span><i>In</i> <a
                                                        href="#">Shopping</a></span> <span><i>Tags</i> <a
                                                        href="#">Trends</a></span> </div>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the
                                                majority .</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 blog-item">
                                    <div class="blog-article">
                                        <div class="post-format"> <span class="post-format-icon"><i
                                                    class="lnr lnr-film-play"></i></span> </div>
                                        <div class="comment-like"> <span><i class="fas fa-comment"
                                                    aria-hidden="true"></i> 30</span> <span><i class="fas fa-heart"
                                                    aria-hidden="true"></i> 15</span> </div>
                                        <div class="article-img">
                                            <a href="blog-single.html"> <img src="images/blog/3.jpeg"
                                                    class="img-responsive" alt=""></a>
                                        </div>
                                        <div class="article-link"> <a href="blog-single.html"><i
                                                    class="lnr lnr-arrow-right"></i></a> </div>
                                        <div class="article-content">
                                            <h4><a href="blog-single.html">Content builder posts</a></h4>
                                            <div class="meta"> <span><i>Feb</i> 16,2016</span> <span><i>In</i> <a
                                                        href="#">Shopping</a></span> <span><i>Tags</i> <a
                                                        href="#">Trends</a></span> </div>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the
                                                majority .</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 blog-item">
                                    <div class="blog-article">
                                        <div class="post-format"> <span class="post-format-icon"><i
                                                    class="lnr lnr-picture"></i></span> </div>
                                        <div class="comment-like"> <span><i class="fas fa-comment"
                                                    aria-hidden="true"></i> 30</span> <span><i class="fas fa-heart"
                                                    aria-hidden="true"></i> 15</span> </div>
                                        <div class="article-img">
                                            <a href="blog-single.html"> <img src="images/blog/4.jpeg"
                                                    class="img-responsive" alt=""></a>
                                        </div>
                                        <div class="article-link"> <a href="blog-single.html"><i
                                                    class="lnr lnr-arrow-right"></i></a> </div>
                                        <div class="article-content">
                                            <h4><a href="blog-single.html">Transitions In Design</a></h4>
                                            <div class="meta"> <span><i>Feb</i> 16,2016</span> <span><i>In</i> <a
                                                        href="#">Shopping</a></span> <span><i>Tags</i> <a
                                                        href="#">Trends</a></span> </div>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the
                                                majority .</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 blog-item">
                                    <div class="blog-article">
                                        <div class="post-format"> <span class="post-format-icon"><i
                                                    class="lnr lnr-picture"></i></span> </div>
                                        <div class="comment-like"> <span><i class="fas fa-comment"
                                                    aria-hidden="true"></i> 30</span> <span><i class="fas fa-heart"
                                                    aria-hidden="true"></i> 15</span> </div>
                                        <div class="article-img">
                                            <a href="blog-single.html"> <img src="images/blog/5.jpeg"
                                                    class="img-responsive" alt=""></a>
                                        </div>
                                        <div class="article-link"> <a href="blog-single.html"><i
                                                    class="lnr lnr-arrow-right"></i></a> </div>
                                        <div class="article-content">
                                            <h4><a href="blog-single.html">Comfort classy outfits</a></h4>
                                            <div class="meta"> <span><i>Feb</i> 16,2016</span> <span><i>In</i> <a
                                                        href="#">Shopping</a></span> <span><i>Tags</i> <a
                                                        href="#">Trends</a></span> </div>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the
                                                majority .</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 blog-item">
                                    <div class="blog-article">
                                        <div class="post-format"> <span class="post-format-icon"><i
                                                    class="lnr lnr-film-play"></i></span> </div>
                                        <div class="comment-like"> <span><i class="fas fa-comment"
                                                    aria-hidden="true"></i> 30</span> <span><i class="fas fa-heart"
                                                    aria-hidden="true"></i> 15</span> </div>
                                        <div class="article-img">
                                            <a href="blog-single.html"> <img src="images/blog/6.jpeg"
                                                    class="img-responsive" alt=""></a>
                                        </div>
                                        <div class="article-link"> <a href="blog-single.html"><i
                                                    class="lnr lnr-arrow-right"></i></a> </div>
                                        <div class="article-content">
                                            <h4><a href="blog-single.html">Recent trends in story</a></h4>
                                            <div class="meta"> <span><i>Feb</i> 16,2016</span> <span><i>In</i> <a
                                                        href="#">Shopping</a></span> <span><i>Tags</i> <a
                                                        href="#">Trends</a></span> </div>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the
                                                majority .</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 blog-item">
                                    <div class="blog-article">
                                        <div class="post-format"> <span class="post-format-icon"><i
                                                    class="lnr lnr-music-note"></i></span></div>
                                        <div class="comment-like"> <span><i class="fas fa-comment"
                                                    aria-hidden="true"></i> 30</span> <span><i class="fas fa-heart"
                                                    aria-hidden="true"></i> 15</span> </div>
                                        <div class="article-img">
                                            <a href="blog-single.html"> <img src="images/blog/7.jpeg"
                                                    class="img-responsive" alt=""></a>
                                        </div>
                                        <div class="article-link"> <a href="blog-single.html"><i
                                                    class="lnr lnr-arrow-right"></i></a> </div>
                                        <div class="article-content">
                                            <h4><a href="blog-single.html">Social media websites</a></h4>
                                            <div class="meta"> <span><i>Feb</i> 16,2016</span> <span><i>In</i> <a
                                                        href="#">Shopping</a></span> <span><i>Tags</i> <a
                                                        href="#">Trends</a></span> </div>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the
                                                majority .</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-6 blog-item-quote blog-item">
                                    <div class="blog-article">
                                        <div class="post-format"> <span class="post-format-icon"><i
                                                    class="lnr lnr-picture"></i></span> </div>
                                        <div class="comment-like"> <span><i class="fas fa-comment"
                                                    aria-hidden="true"></i> 30</span> <span><i class="fas fa-heart"
                                                    aria-hidden="true"></i> 15</span> </div>
                                        <div class="article-img">
                                            <a href="blog-single.html"> <img src="images/blog/8.jpeg"
                                                    class="img-responsive" alt=""></a>
                                        </div>
                                        <div class="article-content">
                                            <div>
                                                <h4><a href="blog-single.html">Design is not just what it looks like
                                                        .Design is how it works .</a></h4>
                                                <div class="meta"> <span><i>Feb</i> 16,2016</span> <span><i>In</i> <a
                                                            href="#">Shopping</a></span> <span><i>Tags</i> <a
                                                            href="#">Trends</a></span> </div>
                                                <div class="article-link"> <a href="blog-single.html"><i
                                                            class="lnr lnr-arrow-right"></i></a> </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="pagination-nav nav-center">
                                <a href="#" class="btn btn-prev"><i class="lnr lnr-arrow-left"></i> prev</a>
                                <a href="#" class="btn btn-next">next <i class="lnr lnr-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- /Blog Subpage -->

                <!-- Contact Subpage -->
                <section id="contact" class="sub-page">
                    <div class="sub-page-inner">
                        <div class="section-title">
                            <div class="main-title">
                                <div class="title-main-page">
                                    <h4>Contact</h4>
                                    <p>NEED SOME HELP?</p>
                                </div>
                            </div>
                        </div>
                        <!-- Contact Form -->
                        <div class="row contact-form pb-30">
                            <div class="col-sm-12 col-md-5 col-lg-5 left-background">
                                <img src="images/mailbox.png" alt="image" />
                            </div>
                            <div class="col-sm-12 col-md-7 col-lg-7">
                                <div class="form-contact-me">
                                    <div id="show_contact_msg"></div>
                                    <form method="post" id="contact-form" action="php/contact.php">
                                        <input name="name" id="name" type="text" placeholder="Name:"
                                            required autocomplete="off">
                                        <input name="email" id="email" type="email" placeholder="Email:"
                                            required autocomplete="off">
                                        <textarea name="comment" id="comment" placeholder="Message:" required rows="6"></textarea>
                                        <input class="bt-submit" type="submit" value="Send Message">
                                    </form>
                                </div>
                            </div>
                        </div>
                        <!-- /Contact Form -->

                        <!-- Contact Details -->
                        <div class="pt-50 pb-30">
                            <div class="section-head">
                                <h4>
                                    <span>Contact Information</span>
                                    Find me here
                                </h4>
                            </div>

                            <!-- Contact Info -->
                            <div class="sidebar-textbox row pb-50">
                                <div class="contact-info d-flex col-md-4">
                                    <div class="w-25">
                                        <div class="contact-icon">
                                            <i class="fas fa-phone"></i>
                                        </div>
                                    </div>
                                    <div class="contact-text w-75">
                                        <h2>Phone</h2>
                                        <p>(+881) 111 222 333</p>
                                        <p>(+881) 111 222 333</p>
                                    </div>
                                </div>
                                <div class="contact-info d-flex col-md-4">
                                    <div class="w-25">
                                        <div class="contact-icon">
                                            <i class="far fa-envelope-open"></i>
                                        </div>
                                    </div>
                                    <div class="contact-text w-75">
                                        <h2>Email</h2>
                                        <p>info@domain.com</p>
                                        <p>name@domain.com</p>
                                    </div>
                                </div>
                                <div class="contact-info d-flex col-md-4">
                                    <div class="w-25">
                                        <div class="contact-icon">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                    </div>
                                    <div class="contact-text w-75">
                                        <h2>Address</h2>
                                        <p>123 New Yourk D Block 1100, <br> Street 2011 USA</p>
                                    </div>
                                </div>
                            </div>
                            <!-- /Contact info -->

                            <!-- Map Container -->
                            <div class="contact-map pt-50">
                                <!-- GOOGLE MAP -->
                                <div id="google-map"></div>
                            </div>
                            <!-- /Map Container -->

                            <!-- Social Media -->
                            <div class="pt-50">
                                <div class="social-media-block">
                                    <h4>Follow Me: </h4>
                                    <ul class="social-media-links">
                                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                        <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
                                        <li><a href="#"><i class="fab fa-behance"></i></a></li>
                                        <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                                        <li><a href="#"><i class="fab fa-snapchat-ghost"></i></a></li>
                                        <li><a href="#"><i class="fab fa-vimeo-v"></i></a></li>
                                        <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- /Social Media -->
                        </div>
                        <!-- /Contact Details -->
                    </div>
                </section>
                <!-- End Contact Subpage -->

                <!-- Appointments Subpage -->
                
                <!-- End Appointments Subpage -->

            </div>
            <!-- /Page changer wrapper -->
        </div>
        <!-- /Main Content -->
    </div>

    <?php echo $__env->make('blocks.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH D:\projects\nghia23d\resources\views/main.blade.php ENDPATH**/ ?>