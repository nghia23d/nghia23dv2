   <!-- Start Page home -->
   <section id="home" class="sub-page start-page">
    <div class="sub-page-inner">
        <div class="mask"></div>
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12">
                <div class="title-block">
                    <h2>Hello I'm Nghia23d</h2>
                    <div class="type-wrap">
                        <div class="typed-strings">
                            <span>Web Developer</span>
                            <span>Photographer</span>
                            <span>Blogger</span>
                        </div>
                        <span class="typed"></span>
                    </div>
                    <div class="home-buttons">
                        <a href="#contact" class="bt-submit"><i class="lnr lnr-envelope"></i> Contact
                            Me</a>
                        <a href="#contact" class="bt-submit"><i class="lnr lnr-briefcase"></i> Hire
                            Me</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /Start Page home --><?php /**PATH D:\projects\nghia23d\resources\views/pages/sections/home.blade.php ENDPATH**/ ?>