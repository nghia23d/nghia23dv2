<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="Mulan / CV Template + RTL" />
<meta name="keywords"
    content="personal, mulan, marwaelmanawy, html5, vcard, resposnive, retina, resume, jquery, css3, bootstrap, portfolio" />
<meta name="author" content="Marwa El-Manawy" />
<link rel="icon" href="favicon.ico">
<title>Nghia23d's Webiste</title>
<!-- Bootstrap -->
<link rel="stylesheet" href="<?php echo e(asset('themes/nghia23d/css/bootstrap.min.css')); ?>" type="text/css">
<!-- Animation -->
<link rel="stylesheet" href="<?php echo e(asset('themes/nghia23d/css/animate.min.css')); ?>" type="text/css">
<!-- Owl Carousel -->
<link rel="stylesheet" href="<?php echo e(asset('themes/nghia23d/css/owl.carousel.min.css')); ?>" type="text/css">
<!-- Light Case -->
<link rel="stylesheet" href="<?php echo e(asset('themes/nghia23d/css/lightcase.min.css')); ?>" type="text/css">
<!-- Template style -->
<link rel="stylesheet" href="<?php echo e(asset('themes/nghia23d/css/style.css')); ?>" type="text/css">
<?php /**PATH D:\projects\nghia23d\resources\views/blocks/head.blade.php ENDPATH**/ ?>