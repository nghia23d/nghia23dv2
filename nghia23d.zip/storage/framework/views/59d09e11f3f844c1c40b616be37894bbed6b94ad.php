 <!-- preloader -->
 <div id="preloader">
    <div id="preloader-circle">
        <span></span>
        <span></span>
    </div>
</div>
<!-- /preloader --><?php /**PATH D:\projects\nghia23d\resources\views/elements/preload.blade.php ENDPATH**/ ?>