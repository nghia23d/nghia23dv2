<!--JS Files-->
<script src="<?php echo e(asset('themes/nghia23d/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('themes/nghia23d/js/bootstrap.min.js')); ?>"></script>
<!--Owl Coursel-->
<script src="<?php echo e(asset('themes/nghia23d/js/owl.carousel.min.js')); ?>"></script>
<!-- Typing Text -->
<script src="<?php echo e(asset('themes/nghia23d/js/typed.min.js')); ?>"></script> 
<!--Images LightCase-->
<script src="<?php echo e(asset('themes/nghia23d/js/lightcase.min.js')); ?>"></script>
<!-- Portfolio filter -->
<script src="<?php echo e(asset('themes/nghia23d/js/jquery.isotope.min.js')); ?>"></script>
<!-- Wow Animation -->
<script src="<?php echo e(asset('themes/nghia23d/js/wow.min.js')); ?>"></script>  
<!-- Main Script -->
<script src="<?php echo e(asset('themes/nghia23d/js/script.js')); ?>"></script><?php /**PATH D:\projects\nghia23d\resources\views/blocks/script.blade.php ENDPATH**/ ?>