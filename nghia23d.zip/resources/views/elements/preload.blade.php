 <!-- preloader -->
 <div id="preloader">
    <div id="preloader-circle">
        <span></span>
        <span></span>
    </div>
</div>
<!-- /preloader -->