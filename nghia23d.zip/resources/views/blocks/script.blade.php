<!--JS Files-->
<script src="{{asset('themes/nghia23d/js/jquery.min.js')}}"></script>
<script src="{{asset('themes/nghia23d/js/bootstrap.min.js')}}"></script>
<!--Owl Coursel-->
<script src="{{asset('themes/nghia23d/js/owl.carousel.min.js')}}"></script>
<!-- Typing Text -->
<script src="{{asset('themes/nghia23d/js/typed.min.js')}}"></script> 
<!--Images LightCase-->
<script src="{{asset('themes/nghia23d/js/lightcase.min.js')}}"></script>
<!-- Portfolio filter -->
<script src="{{asset('themes/nghia23d/js/jquery.isotope.min.js')}}"></script>
<!-- Wow Animation -->
<script src="{{asset('themes/nghia23d/js/wow.min.js')}}"></script>  
<!-- Main Script -->
<script src="{{asset('themes/nghia23d/js/script.js')}}"></script>