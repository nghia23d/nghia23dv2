@extends('layout')

@section('content')
    @include('pages.sections.home')

    @include('pages.sections.about_me')

    @include('pages.sections.portfolio')

    @include('pages.sections.blog')

    @include('pages.sections.contact')
@endsection
